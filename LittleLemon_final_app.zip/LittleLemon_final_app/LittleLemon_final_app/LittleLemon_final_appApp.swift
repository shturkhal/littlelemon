//
//  LittleLemon_final_appApp.swift
//  LittleLemon_final_app
//
//  Created by Ivan Shturkhal on 03.06.2024.
//

import SwiftUI

@main
struct LittleLemon_final_app: App {
    let persistenceController = PersistenceController.shared
    
    var body: some Scene {
        WindowGroup {
            Onboarding().environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
